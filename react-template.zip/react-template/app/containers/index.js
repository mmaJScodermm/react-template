import React , { Component } from 'react';
import { connect } from 'react-redux';
import PureRenderMixin from 'react-addons-pure-render-mixin';

class App extends Component {
	constructor(props,context){
		super(props,context);
		this.shouldComponentUpdate = PureRenderMixin.shouldComponentUpdate.bind(this);
		this.state={
			initDown:false
		}
	}
	render(){
		return (
			<div>{this.props.children}</div>
		)
	}
}

export default connect((store)=>{
	return {
		a:store.a
	}
})(App);
