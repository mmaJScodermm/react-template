export default ( store={
	a:1
},{ 
	type , payload
})=>{
	return store;
}