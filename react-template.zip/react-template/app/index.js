import React from 'react'
import { render } from 'react-dom'


render(
    <div>Hello React</div>
    ,
    document.getElementById('root')
)
